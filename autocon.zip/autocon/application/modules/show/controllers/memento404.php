<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Memento admin Controller
 *
 * This class handles user account related functionality
 *
 * @package		Memento404
 * @subpackage	Memento404
 * @author		webhelios
 * @link		http://webhelios.com
 */
require_once 'memento404_core.php';
class Memento404 extends Memento404_core {

	public function __construct()
	{
		parent::__construct();
	}
}
/* End of file install.php */
/* Location: ./application/modules/show/controllers/memento404.php */