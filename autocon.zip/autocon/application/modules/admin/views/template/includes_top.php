<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/admin/assets/bootstrap/css/bootstrap.min.css">
<link href="<?php echo theme_url();?>/assets/css/font-awesome.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/admin/css/dbcadmin.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/admin/css/memento-responsive.css">

<!--Table-->
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/admin/assets/data-tables/bootstrap3/dataTables.bootstrap.css" />


<!--Rickh Text Editor-->
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/admin/assets/bootstrap-wysihtml5/bootstrap-wysihtml5.css" />

<!--Rickh Text Editor-->

<link href="<?php echo base_url();?>assets/admin/css/no-more-table.css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/admin/css/custom-admin.css" rel="stylesheet">

<link rel="shortcut icon" href="<?php echo base_url();?>assets/admin/img/favicon.png">

<script src="<?php echo base_url();?>assets/admin/js/jquery-2.1.1.min.js"></script>
<script src="<?php echo base_url();?>assets/admin/js/jquery-migrate-1.2.1.min.js"></script>
<script>window.jQuery || document.write('<script src="<?php echo base_url();?>assets/admin/assets/jquery/jquery-2.1.1.min.js"><\/script>')</script>
<script type="text/javascript">
	var dt_first = '<?php echo lang_key("dt_first");?>';
	var dt_last = '<?php echo lang_key("dt_last");?>';
	var dt_next = '<?php echo lang_key("dt_next");?>';
	var dt_prev = '<?php echo lang_key("dt_prev");?>';
	var dt_no_data = '<?php echo lang_key("dt_no_data");?>';
	var dt_show_empty = '<?php echo lang_key("dt_show_empty");?>';
	var dt_no_match = '<?php echo lang_key("dt_no_match");?>';
	var dt_search = '<?php echo lang_key("dt_search");?>';
	var dt_processing = '<?php echo lang_key("dt_processing");?>';
	var dt_loading = '<?php echo lang_key("dt_loading");?>';
	var dt_info = '<?php echo lang_key("dt_info");?>';
	var dt_filter_info = '<?php echo lang_key("dt_filter_info");?>';
	var dt_show_entries = '<?php echo lang_key("dt_show_entries");?>';
</script>
