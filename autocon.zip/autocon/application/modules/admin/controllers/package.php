<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Memento memento Controller
 *
 * This class handles memento management related functionality
 *
 * @package		Admin
 * @subpackage	memento
 * @author		webhelios
 * @link		http://webhelios.com
 */
require_once'package_core.php';
class Package extends Package_core {

	public function __construct()
	{
		parent::__construct();
	}
}