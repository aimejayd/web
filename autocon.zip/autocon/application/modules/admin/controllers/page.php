<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Memento page Controller
 *
 * This class handles page management related functionality
 *
 * @package		Admin
 * @subpackage	Page
 * @author		webhelios
 * @link		http://webhelios.com
 */

require_once'page_core.php';

class Page extends Page_core {
	
	public function __construct()
	{
		parent::__construct();
	}
	
	
}

/* End of file page.php */
/* Location: ./application/modules/admin/controllers/page.php */