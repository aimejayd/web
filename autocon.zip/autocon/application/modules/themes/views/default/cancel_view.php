<h1 class="widget-title"><i class="fa fa-user"></i>&nbsp;<?php echo lang_key('bi_payment_cancel_title');?></h1>
<div class="row">
    <div class="col-md-12" style="min-height:300px">
	<p><?php echo lang_key('payment_cancel_text');?></p>
	</div>
</div>