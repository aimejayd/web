<div class="row">
    <div class="col-md-12" style="min-height:300px">
        <?php echo $this->session->flashdata('msg');?>
    </div>
</div>      