<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Memento admin Controller
 *
 * This class handles user account related functionality
 *
 * @package		Install
 * @subpackage	Install
 * @author		webhelios
 * @link		http://webhelios.com
 */
require_once'install_core.php';
class Install extends Install_core {

	public function __construct()
	{
		parent::__construct();
	}
	
}

/* End of file install.php */
/* Location: ./application/modules/install/controllers/install.php */