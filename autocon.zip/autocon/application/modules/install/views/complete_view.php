<img src="<?php echo base_url('assets/admin/icons');?>/complete.png" style="width:260px;height:18-px;" />
<p class="lead">Setup is complete :D</p>
<ul class="inline">
	<li><a href="<?php echo site_url();?>" class="btn btn-success">Visit Site</a></li>
	<li><a href="<?php echo site_url('admin');?>" class="btn btn-info">Admin Panel</a></li>
</ul>