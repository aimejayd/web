<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Memento admin Controller
 *
 * This class handles user account related functionality
 *
 * @package		User
 * @subpackage	User
 * @author		webhelios
 * @link		http://webhelios.com
 */
require_once'user_core.php';
class User extends User_core {

	public function __construct()
	{
		parent::__construct();
	}
}
/* End of file install.php */
/* Location: ./application/modules/user/controllers/user.php */