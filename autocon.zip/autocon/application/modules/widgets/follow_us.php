<h3 class="widget-title">Follow me</h3>
                        <div class="widget-body">
                            <p class="follow-me-icons">
                               <a href=""><i class="fa fa-facebook fa-2"></i></a>
                                <a href=""><i class="fa fa-twitter fa-2"></i></a>
                                <a href=""><i class="fa fa-google-plus fa-2"></i></a>
                                <a  href="<?php echo site_url("show/rss");?>"><i class="fa fa-rss fa-2"></i></a>
                            </p>    
                        </div>